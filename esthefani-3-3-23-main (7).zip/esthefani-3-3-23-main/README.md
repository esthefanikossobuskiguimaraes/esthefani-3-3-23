# turmaM-3tri
Terça-feira das 14h às 15h40
